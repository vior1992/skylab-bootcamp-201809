![Logo Skylab](https://pbs.twimg.com/profile_images/718411051340079104/xJ-vRtnD_400x400.jpg)

# Precurs Skylab

Projectes:

* Calculadora
* Skylab Airlines
* Bingo
* Memory Alphabet
